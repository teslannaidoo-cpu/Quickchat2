import java.util.Scanner;

public class Quickchat {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("Welcome to QuickChat");

        System.out.print("How many messages would you like to send? ");
        int totalMessages = input.nextInt();
        input.nextLine();

        int sentMessages = 0;

        while (true) {

            System.out.println("\nChoose an option:");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");

            int choice = input.nextInt();
            input.nextLine();

            if (choice == 1) {

                if (sentMessages < totalMessages) {

                    System.out.print("Enter your message: ");
                    String message = input.nextLine();

                    System.out.println("Message sent: " + message);

                    sentMessages++;

                } else {
                    System.out.println("Message limit reached.");
                }

            } else if (choice == 2) {

                System.out.println("Recently sent messages feature coming soon.");

            } else if (choice == 3) {

                System.out.println("Total messages sent: " + sentMessages);
                System.out.println("Goodbye!");
                break;

            } else {

                System.out.println("Invalid option.");
            }
        }

        input.close();
    }
}